# Hyperlokale Njob App
Dies ist die React/Next.js-App für hyperlokale Nebenjobs.